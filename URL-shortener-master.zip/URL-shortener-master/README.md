# URL-shortener

This is a simple flask app which takes an URL and shortens it. This shortened verion of the URL redirects to the user to the long URL. 

For each long URL given by the user the application randomly generates an alphabetical combination which redirects to the long URL.

# Webiste hosted on heroku
https://tinyurlanish.herokuapp.com/

# Youtube Tutorial
https://www.youtube.com/watch?v=YI16KWyA3M0
